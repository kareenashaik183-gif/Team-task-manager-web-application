import { Link } from "wouter";
import { 
  useGetDashboardSummary, getGetDashboardSummaryQueryKey,
  useGetOverdueTasks, getGetOverdueTasksQueryKey,
  useGetRecentActivity, getGetRecentActivityQueryKey
} from "@workspace/api-client-react";
import { 
  Card, CardContent, CardHeader, CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  CheckCircle2, Clock, PlayCircle, AlertCircle, 
  FolderKanban, Users, ArrowRight, Activity
} from "lucide-react";

function StatCard({ title, value, icon: Icon, colorClass, isLoading }: { title: string; value: number; icon: React.ElementType; colorClass: string; isLoading: boolean }) {
  return (
    <Card>
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          {isLoading ? (
            <Skeleton className="h-8 w-16 mt-1" />
          ) : (
            <h3 className="text-2xl font-bold tracking-tight mt-1">{value}</h3>
          )}
        </div>
        <div className={`p-3 rounded-full ${colorClass}`}>
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const { data: summary, isLoading: isSummaryLoading } = useGetDashboardSummary({
    query: { queryKey: getGetDashboardSummaryQueryKey() }
  });

  const { data: overdueTasks, isLoading: isOverdueLoading } = useGetOverdueTasks({
    query: { queryKey: getGetOverdueTasksQueryKey() }
  });

  const { data: recentActivity, isLoading: isActivityLoading } = useGetRecentActivity({
    query: { queryKey: getGetRecentActivityQueryKey() }
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your team's workspace.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard 
          title="Total Tasks" 
          value={summary?.totalTasks ?? 0} 
          icon={CheckCircle2} 
          colorClass="bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400" 
          isLoading={isSummaryLoading} 
        />
        <StatCard 
          title="Pending" 
          value={summary?.pendingTasks ?? 0} 
          icon={Clock} 
          colorClass="bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400" 
          isLoading={isSummaryLoading} 
        />
        <StatCard 
          title="In Progress" 
          value={summary?.inProgressTasks ?? 0} 
          icon={PlayCircle} 
          colorClass="bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400" 
          isLoading={isSummaryLoading} 
        />
        <StatCard 
          title="Completed" 
          value={summary?.completedTasks ?? 0} 
          icon={CheckCircle2} 
          colorClass="bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400" 
          isLoading={isSummaryLoading} 
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-destructive" />
                Overdue Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isOverdueLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-14 w-full" />)}
                </div>
              ) : overdueTasks && overdueTasks.length > 0 ? (
                <div className="space-y-3">
                  {overdueTasks.slice(0, 5).map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors" data-testid={`overdue-task-${task.id}`}>
                      <div className="min-w-0 flex-1">
                        <Link href={`/tasks/${task.id}`}>
                          <div className="font-medium text-sm truncate hover:underline cursor-pointer">
                            {task.title}
                          </div>
                        </Link>
                        <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                          <Badge variant="outline" className="text-destructive border-destructive/30 text-xs">
                            Overdue
                          </Badge>
                          <span className="truncate">{task.project?.title ?? 'No Project'}</span>
                        </div>
                      </div>
                      <Link href={`/tasks/${task.id}`}>
                        <Button size="sm" variant="ghost">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground border rounded-lg border-dashed">
                  <CheckCircle2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No overdue tasks. Great job!</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isActivityLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
                </div>
              ) : recentActivity && recentActivity.length > 0 ? (
                <div className="space-y-3">
                  {recentActivity.slice(0, 5).map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors" data-testid={`activity-task-${task.id}`}>
                      <div className="min-w-0 flex-1">
                        <Link href={`/tasks/${task.id}`}>
                          <div className="font-medium text-sm truncate hover:underline cursor-pointer">{task.title}</div>
                        </Link>
                        <div className="text-xs text-muted-foreground mt-1">
                          {task.assignedTo?.name ?? 'Unassigned'} · {task.project?.title ?? 'No Project'}
                        </div>
                      </div>
                      <Badge variant={task.status === 'Completed' ? 'default' : task.status === 'In Progress' ? 'secondary' : 'outline'} className="ml-2 text-xs shrink-0">
                        {task.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground border rounded-lg border-dashed">
                  <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No recent activity yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Workspace Stats</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-md">
                    <FolderKanban className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium text-sm">Projects</span>
                </div>
                {isSummaryLoading ? <Skeleton className="h-5 w-8" /> : <span className="font-bold">{summary?.totalProjects ?? 0}</span>}
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-md">
                    <Users className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium text-sm">Team Members</span>
                </div>
                {isSummaryLoading ? <Skeleton className="h-5 w-8" /> : <span className="font-bold">{summary?.totalMembers ?? 0}</span>}
              </div>
              <div className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-destructive/10 rounded-md">
                    <AlertCircle className="h-4 w-4 text-destructive" />
                  </div>
                  <span className="font-medium text-sm">Overdue</span>
                </div>
                {isSummaryLoading ? <Skeleton className="h-5 w-8" /> : <span className="font-bold text-destructive">{summary?.overdueTasks ?? 0}</span>}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
