import { useState, useEffect, useRef } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useGetTask, getGetTaskQueryKey,
  useUpdateTask,
  useDeleteTask,
  useListProjects,
  useListUsers,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Trash2, Save, Calendar, Clock, User as UserIcon, FolderKanban } from "lucide-react";
import { format } from "date-fns";
import { UpdateTaskBodyStatus } from "@workspace/api-client-react/src/generated/api.schemas";

export default function TaskDetail() {
  const [, params] = useRoute("/tasks/:id");
  const taskId = Number(params?.id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [status, setStatus] = useState<UpdateTaskBodyStatus>("Pending");
  const [projectId, setProjectId] = useState<string>("unassigned");
  const [assigneeId, setAssigneeId] = useState<string>("unassigned");
  
  const isInitialized = useRef<number | null>(null);

  const { data: task, isLoading: isTaskLoading } = useGetTask(taskId, {
    query: { enabled: !!taskId, queryKey: getGetTaskQueryKey(taskId) }
  });

  const { data: projects } = useListProjects();
  const { data: users } = useListUsers();

  useEffect(() => {
    if (task && isInitialized.current !== task.id) {
      isInitialized.current = task.id;
      setTitle(task.title);
      setDescription(task.description || "");
      setStatus(task.status as UpdateTaskBodyStatus);
      setProjectId(task.projectId ? task.projectId.toString() : "unassigned");
      setAssigneeId(task.assignedToId ? task.assignedToId.toString() : "unassigned");
    }
  }, [task]);

  const updateTask = useUpdateTask({
    mutation: {
      onSuccess: (data) => {
        toast({ title: "Task saved" });
        queryClient.setQueryData(getGetTaskQueryKey(taskId), data);
      }
    }
  });

  const deleteTask = useDeleteTask({
    mutation: {
      onSuccess: () => {
        toast({ title: "Task deleted" });
        if (task?.projectId) {
          setLocation(`/projects/${task.projectId}`);
        } else {
          setLocation("/tasks");
        }
      }
    }
  });

  const handleSave = () => {
    updateTask.mutate({
      id: taskId,
      data: {
        title,
        description,
        status,
        projectId: projectId !== "unassigned" ? Number(projectId) : undefined,
        assignedToId: assigneeId !== "unassigned" ? Number(assigneeId) : undefined
      }
    });
  };

  if (isTaskLoading) {
    return <div className="space-y-6 max-w-3xl mx-auto">
      <Skeleton className="h-8 w-24" />
      <Skeleton className="h-12 w-full" />
      <Skeleton className="h-64 w-full" />
    </div>;
  }

  if (!task) return <div>Task not found</div>;

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
        {task.projectId ? (
          <>
            <Link href={`/projects/${task.projectId}`} className="hover:text-foreground hover:underline flex items-center">
              <ArrowLeft className="h-4 w-4 mr-1" /> Back to Project
            </Link>
          </>
        ) : (
          <Link href="/tasks" className="hover:text-foreground hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Tasks
          </Link>
        )}
      </div>

      <div className="flex items-start justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Edit Task</h1>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="text-destructive hover:bg-destructive/10"
            onClick={() => {
              if (confirm("Are you sure you want to delete this task?")) {
                deleteTask.mutate({ id: taskId });
              }
            }}
          >
            <Trash2 className="h-4 w-4 mr-2" /> Delete
          </Button>
          <Button size="sm" onClick={handleSave} disabled={updateTask.isPending}>
            <Save className="h-4 w-4 mr-2" /> Save Changes
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Task Title</Label>
            <Input 
              id="title" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              className="text-lg font-medium"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-border/50">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-muted-foreground"><Clock className="h-4 w-4" /> Status</Label>
                <Select value={status} onValueChange={(val) => setStatus(val as UpdateTaskBodyStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-muted-foreground"><FolderKanban className="h-4 w-4" /> Project</Label>
                <Select value={projectId} onValueChange={setProjectId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Unassigned" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unassigned">No Project</SelectItem>
                    {projects?.map(p => (
                      <SelectItem key={p.id} value={p.id.toString()}>{p.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-muted-foreground"><UserIcon className="h-4 w-4" /> Assignee</Label>
                <Select value={assigneeId} onValueChange={setAssigneeId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Unassigned" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                    {users?.map(u => (
                      <SelectItem key={u.id} value={u.id.toString()}>{u.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2 h-full flex flex-col">
              <Label>Description</Label>
              <Textarea 
                value={description} 
                onChange={(e) => setDescription(e.target.value)}
                className="flex-1 min-h-[150px] resize-none"
                placeholder="Add task details, links, or context here..."
              />
            </div>
          </div>

          <div className="pt-4 border-t border-border/50 flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" />
              <span>Created {format(new Date(task.createdAt), "MMM d, yyyy 'at' h:mm a")}</span>
            </div>
            <div>
              <span>Last updated {format(new Date(task.updatedAt), "MMM d, yyyy 'at' h:mm a")}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
