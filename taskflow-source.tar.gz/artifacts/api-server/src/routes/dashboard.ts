import { Router, type IRouter } from "express";
import { lt, ne, and, isNotNull } from "drizzle-orm";
import { db, tasksTable, usersTable, projectsTable } from "@workspace/db";
import { GetDashboardSummaryResponse, GetRecentActivityResponse, GetOverdueTasksResponse } from "@workspace/api-zod";
import { authMiddleware } from "../middlewares/auth";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/dashboard/summary", authMiddleware, async (_req, res): Promise<void> => {
  const [totalTasksRow] = await db.execute(sql`SELECT COUNT(*) as count FROM tasks`);
  const [pendingRow] = await db.execute(sql`SELECT COUNT(*) as count FROM tasks WHERE status = 'Pending'`);
  const [inProgressRow] = await db.execute(sql`SELECT COUNT(*) as count FROM tasks WHERE status = 'In Progress'`);
  const [completedRow] = await db.execute(sql`SELECT COUNT(*) as count FROM tasks WHERE status = 'Completed'`);
  const [overdueRow] = await db.execute(sql`SELECT COUNT(*) as count FROM tasks WHERE due_date < NOW() AND status != 'Completed'`);
  const [totalProjectsRow] = await db.execute(sql`SELECT COUNT(*) as count FROM projects`);
  const [totalMembersRow] = await db.execute(sql`SELECT COUNT(*) as count FROM users`);

  const summary = {
    totalTasks: Number((totalTasksRow as { count: string }).count),
    pendingTasks: Number((pendingRow as { count: string }).count),
    inProgressTasks: Number((inProgressRow as { count: string }).count),
    completedTasks: Number((completedRow as { count: string }).count),
    overdueTasks: Number((overdueRow as { count: string }).count),
    totalProjects: Number((totalProjectsRow as { count: string }).count),
    totalMembers: Number((totalMembersRow as { count: string }).count),
  };

  res.json(GetDashboardSummaryResponse.parse(summary));
});

router.get("/dashboard/recent-activity", authMiddleware, async (_req, res): Promise<void> => {
  const tasks = await db.select().from(tasksTable).orderBy(sql`updated_at DESC`).limit(10);

  const enriched = await Promise.all(
    tasks.map(async (task) => {
      let assignedTo = null;
      if (task.assignedToId) {
        const [u] = await db
          .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
          .from(usersTable)
          .where(sql`id = ${task.assignedToId}`);
        assignedTo = u ?? null;
      }

      let project = null;
      if (task.projectId) {
        const [p] = await db.select().from(projectsTable).where(sql`id = ${task.projectId}`);
        if (p) project = { ...p, members: [], memberIds: [], taskCount: 0 };
      }

      return { ...task, assignedTo, project };
    })
  );

  res.json(GetRecentActivityResponse.parse(enriched));
});

router.get("/dashboard/overdue-tasks", authMiddleware, async (_req, res): Promise<void> => {
  const tasks = await db
    .select()
    .from(tasksTable)
    .where(sql`due_date IS NOT NULL AND due_date < NOW() AND status != 'Completed'`)
    .orderBy(tasksTable.dueDate);

  const enriched = await Promise.all(
    tasks.map(async (task) => {
      let assignedTo = null;
      if (task.assignedToId) {
        const [u] = await db
          .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
          .from(usersTable)
          .where(sql`id = ${task.assignedToId}`);
        assignedTo = u ?? null;
      }

      let project = null;
      if (task.projectId) {
        const [p] = await db.select().from(projectsTable).where(sql`id = ${task.projectId}`);
        if (p) project = { ...p, members: [], memberIds: [], taskCount: 0 };
      }

      return { ...task, assignedTo, project };
    })
  );

  res.json(GetOverdueTasksResponse.parse(enriched));
});

export default router;
