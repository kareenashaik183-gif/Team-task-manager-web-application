import { Router, type IRouter } from "express";
import { eq, and, isNull } from "drizzle-orm";
import { db, tasksTable, usersTable, projectsTable, projectMembersTable } from "@workspace/db";
import {
  CreateTaskBody,
  UpdateTaskBody,
  GetTaskParams,
  UpdateTaskParams,
  DeleteTaskParams,
  ListTasksQueryParams,
  ListTasksResponse,
  GetTaskResponse,
  UpdateTaskResponse,
} from "@workspace/api-zod";
import { authMiddleware } from "../middlewares/auth";

const router: IRouter = Router();

async function buildTask(taskId: number) {
  const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, taskId));
  if (!task) return null;

  let assignedTo = null;
  if (task.assignedToId) {
    const [u] = await db
      .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
      .from(usersTable)
      .where(eq(usersTable.id, task.assignedToId));
    assignedTo = u ?? null;
  }

  let project = null;
  if (task.projectId) {
    const [p] = await db.select().from(projectsTable).where(eq(projectsTable.id, task.projectId));
    if (p) {
      const members = await db
        .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
        .from(projectMembersTable)
        .innerJoin(usersTable, eq(projectMembersTable.userId, usersTable.id))
        .where(eq(projectMembersTable.projectId, p.id));
      project = { ...p, members, memberIds: members.map((m) => m.id), taskCount: 0 };
    }
  }

  return { ...task, assignedTo, project };
}

router.get("/tasks", authMiddleware, async (req, res): Promise<void> => {
  const queryParsed = ListTasksQueryParams.safeParse(req.query);
  if (!queryParsed.success) {
    res.status(400).json({ message: queryParsed.error.message });
    return;
  }

  const { projectId, assignedTo, status } = queryParsed.data;

  const conditions = [];
  if (projectId !== undefined) conditions.push(eq(tasksTable.projectId, projectId));
  if (assignedTo !== undefined) conditions.push(eq(tasksTable.assignedToId, assignedTo));
  if (status !== undefined) conditions.push(eq(tasksTable.status, status));

  const tasks = conditions.length > 0
    ? await db.select().from(tasksTable).where(and(...conditions)).orderBy(tasksTable.createdAt)
    : await db.select().from(tasksTable).orderBy(tasksTable.createdAt);

  const enriched = await Promise.all(tasks.map((t) => buildTask(t.id)));
  res.json(ListTasksResponse.parse(enriched.filter(Boolean)));
});

router.post("/tasks", authMiddleware, async (req, res): Promise<void> => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { title, description, projectId, assignedToId, status, dueDate } = parsed.data;
  const [task] = await db
    .insert(tasksTable)
    .values({ title, description, projectId, assignedToId, status: status ?? "Pending", dueDate })
    .returning();

  const full = await buildTask(task.id);
  res.status(201).json(GetTaskResponse.parse(full));
});

router.get("/tasks/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = GetTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  const full = await buildTask(params.data.id);
  if (!full) {
    res.status(404).json({ message: "Task not found" });
    return;
  }

  res.json(GetTaskResponse.parse(full));
});

router.put("/tasks/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = UpdateTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  const parsed = UpdateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { title, description, projectId, assignedToId, status, dueDate } = parsed.data;
  const [updated] = await db
    .update(tasksTable)
    .set({
      ...(title !== undefined && { title }),
      ...(description !== undefined && { description }),
      ...(projectId !== undefined && { projectId }),
      ...(assignedToId !== undefined && { assignedToId }),
      ...(status !== undefined && { status }),
      ...(dueDate !== undefined && { dueDate }),
      updatedAt: new Date(),
    })
    .where(eq(tasksTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ message: "Task not found" });
    return;
  }

  const full = await buildTask(params.data.id);
  res.json(UpdateTaskResponse.parse(full));
});

router.delete("/tasks/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = DeleteTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  await db.delete(tasksTable).where(eq(tasksTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
