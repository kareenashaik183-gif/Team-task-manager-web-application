import { Router, type IRouter } from "express";
import { eq, sql, inArray } from "drizzle-orm";
import { db, projectsTable, projectMembersTable, usersTable } from "@workspace/db";
import {
  CreateProjectBody,
  UpdateProjectBody,
  GetProjectParams,
  UpdateProjectParams,
  DeleteProjectParams,
  ListProjectsResponse,
  GetProjectResponse,
  UpdateProjectResponse,
} from "@workspace/api-zod";
import { authMiddleware } from "../middlewares/auth";

const router: IRouter = Router();

async function buildProjectWithMembers(projectId: number) {
  const [project] = await db.select().from(projectsTable).where(eq(projectsTable.id, projectId));
  if (!project) return null;

  const members = await db
    .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
    .from(projectMembersTable)
    .innerJoin(usersTable, eq(projectMembersTable.userId, usersTable.id))
    .where(eq(projectMembersTable.projectId, projectId));

  const [taskCountRow] = await db.execute(
    sql`SELECT COUNT(*) as count FROM tasks WHERE project_id = ${projectId}`
  );
  const taskCount = Number((taskCountRow as { count: string }).count ?? 0);

  return {
    ...project,
    members,
    memberIds: members.map((m) => m.id),
    taskCount,
  };
}

router.get("/projects", authMiddleware, async (_req, res): Promise<void> => {
  const projects = await db.select().from(projectsTable).orderBy(projectsTable.createdAt);

  const enriched = await Promise.all(
    projects.map(async (p) => {
      const members = await db
        .select({ id: usersTable.id, name: usersTable.name, email: usersTable.email, role: usersTable.role, createdAt: usersTable.createdAt })
        .from(projectMembersTable)
        .innerJoin(usersTable, eq(projectMembersTable.userId, usersTable.id))
        .where(eq(projectMembersTable.projectId, p.id));

      const [taskCountRow] = await db.execute(
        sql`SELECT COUNT(*) as count FROM tasks WHERE project_id = ${p.id}`
      );
      const taskCount = Number((taskCountRow as { count: string }).count ?? 0);

      return { ...p, members, memberIds: members.map((m) => m.id), taskCount };
    })
  );

  res.json(ListProjectsResponse.parse(enriched));
});

router.post("/projects", authMiddleware, async (req, res): Promise<void> => {
  const parsed = CreateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { title, description, memberIds } = parsed.data;
  const [project] = await db.insert(projectsTable).values({ title, description }).returning();

  if (memberIds && memberIds.length > 0) {
    await db.insert(projectMembersTable).values(memberIds.map((userId) => ({ projectId: project.id, userId })));
  }

  const full = await buildProjectWithMembers(project.id);
  res.status(201).json(GetProjectResponse.parse(full));
});

router.get("/projects/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = GetProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  const full = await buildProjectWithMembers(params.data.id);
  if (!full) {
    res.status(404).json({ message: "Project not found" });
    return;
  }

  res.json(GetProjectResponse.parse(full));
});

router.put("/projects/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = UpdateProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  const parsed = UpdateProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { title, description, memberIds } = parsed.data;
  const [updated] = await db
    .update(projectsTable)
    .set({ title, description, updatedAt: new Date() })
    .where(eq(projectsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ message: "Project not found" });
    return;
  }

  if (memberIds !== undefined) {
    await db.delete(projectMembersTable).where(eq(projectMembersTable.projectId, params.data.id));
    if (memberIds.length > 0) {
      await db.insert(projectMembersTable).values(memberIds.map((userId) => ({ projectId: params.data.id, userId })));
    }
  }

  const full = await buildProjectWithMembers(params.data.id);
  res.json(UpdateProjectResponse.parse(full));
});

router.delete("/projects/:id", authMiddleware, async (req, res): Promise<void> => {
  const params = DeleteProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ message: params.error.message });
    return;
  }

  await db.delete(projectsTable).where(eq(projectsTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
